package Modelo;

import java.sql.*;

public class ConsultasSeleccion {
    
   public Integer mayor, diferencia;
   public String nombre, nombreS;
    
    public void eliminar(Connection conexion, Seleccion d)throws SQLException{
    
        try{
            
           PreparedStatement consulta;
           consulta = conexion.prepareStatement("DELETE FROM seleccion WHERE `seleccion`.`id`=?");
           consulta.setInt(1, d.getId());
       
           consulta.executeUpdate();
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
    
    }
    
    public void buscar(Connection conexion, Seleccion d) throws SQLException{
    
        try{
            
           PreparedStatement consulta;
           consulta = conexion.prepareStatement("select * from seleccion where id=? ");
           consulta.setInt(1, d.getId());
          ResultSet rs = consulta.executeQuery();
          
          while(rs.next()){
              
              d.setNombre(rs.getString("nombre"));
              d.setContinente(rs.getInt("continente_id"));
              d.setTecnico(rs.getString("tecnico"));
              d.setGolesF(rs.getInt("goles_favor"));
              d.setGolesC(rs.getInt("goles_contra"));
              d.setPartidosG(rs.getInt("partidos_ganados"));
              d.setPartidosP(rs.getInt("partidos_perdidos"));
              d.setPartidosJ(rs.getInt("partidos_jugados"));
              
              
             
          
          }
         
           
          
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
    }
    
    public void actualizar(Connection conexion, Seleccion d) throws SQLException{
    
        try{
            
           PreparedStatement consulta;
           consulta = conexion.prepareStatement("UPDATE seleccion set nombre=?,continente_id=?, tecnico=?, goles_favor=?, goles_contra=?, partidos_ganados=?, partidos_perdidos=?, partidos_jugados=? where id=?");
          
           consulta.setString(1, d.getNombre());
           consulta.setInt(2, d.getContinente());
           consulta.setString(3, d.getTecnico());
           consulta.setInt(4, d.getGolesF());
           consulta.setInt(5, d.getGolesC());
           consulta.setInt(6, d.getPartidosG());
           consulta.setInt(7, d.getPartidosP());
           consulta.setInt(8, d.getPartidosJ());
           consulta.setInt(9,d.getId());
           consulta.executeUpdate();
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
    }
    
    public void guardar(Connection conexion, Seleccion d) throws SQLException{
    
        try{
            
           PreparedStatement consulta;
           consulta = conexion.prepareStatement("INSERT INTO seleccion (id, nombre, continente_id, tecnico, goles_favor, goles_contra, partidos_ganados, partidos_perdidos, partidos_jugados)"+"VALUES(?,?,?,?,?,?,?,?,?)");
           consulta.setInt(1, d.getId());
           consulta.setString(2, d.getNombre());
           consulta.setInt(3, d.getContinente());
           consulta.setString(4, d.getTecnico());
           consulta.setInt(5, d.getGolesF());
           consulta.setInt(6, d.getGolesC());
           consulta.setInt(7, d.getPartidosG());
           consulta.setInt(8, d.getPartidosP());
           consulta.setInt(9, d.getPartidosJ());
           consulta.executeUpdate();
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
        
        
   
    }
    
    public void mayorGoles(Connection conexion, Seleccion d)throws SQLException{
      
         
        try{
            
           Statement sta = conexion.createStatement();
           String consulta = "select max(partidos_ganados) as mayor,max(nombre) as nombre from seleccion";
           ResultSet rs = sta.executeQuery(consulta);
      
           rs.next();
            mayor = rs.getInt("mayor");
          
            nombre = rs.getString("nombre");
       
       
      
         
           rs.close();
           sta.close();
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
        
    }
    
    public void mayorDif(Connection conexion, Seleccion d)throws SQLException{
      
         
        try{
            
           Statement sta = conexion.createStatement();
           String consulta = "SELECT goles_favor - goles_contra as diferencia, nombre from seleccion ORDER BY `diferencia` DESC";
           ResultSet rs = sta.executeQuery(consulta);
      
           rs.next();
            diferencia = rs.getInt("diferencia");
            
          
            nombreS = rs.getString("nombre");
       
       
      
         
           rs.close();
           sta.close();
            
        }
        catch (SQLException ex){
            
            throw new SQLException(ex);
        
        }
        
    }
}
