package Modelo;

public class Seleccion {
    
    private int Id;
    private String nombre;
    private int continente;
    private String tecnico;
    private int golesF;
    private int golesC;
    private int partidosG;
    private int partidosP;
    private int partidosJ;

    public Seleccion(int Id, String nombre, int continente, String tecnico, int golesF, int golesC, int partidosG, int partidosP, int partidosJ) {
        this.Id = Id;
        this.nombre = nombre;
        this.continente = continente;
        this.tecnico = tecnico;
        this.golesF = golesF;
        this.golesC = golesC;
        this.partidosG = partidosG;
        this.partidosP = partidosP;
        this.partidosJ = partidosJ;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getContinente() {
        return continente;
    }

    public void setContinente(int continente) {
        this.continente = continente;
    }

    public String getTecnico() {
        return tecnico;
    }

    public void setTecnico(String tecnico) {
        this.tecnico = tecnico;
    }

    public int getGolesF() {
        return golesF;
    }

    public void setGolesF(int golesF) {
        this.golesF = golesF;
    }

    public int getGolesC() {
        return golesC;
    }

    public void setGolesC(int golesC) {
        this.golesC = golesC;
    }

    public int getPartidosG() {
        return partidosG;
    }

    public void setPartidosG(int partidosG) {
        this.partidosG = partidosG;
    }

    public int getPartidosP() {
        return partidosP;
    }

    public void setPartidosP(int partidosP) {
        this.partidosP = partidosP;
    }

    public int getPartidosE() {
        return partidosJ;
    }

    public void setPartidosE(int partidosE) {
        this.partidosJ = partidosE;
    }

    void setPartidosJ(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int getPartidosJ() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
