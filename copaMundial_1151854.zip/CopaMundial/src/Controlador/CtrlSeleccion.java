
package Controlador;

import Modelo.*;
import copamundial.copaMundial;

public class CtrlSeleccion {
    
    public void RegistrarD(Seleccion d){
        
         try{
        
            ConsultasSeleccion ds = new ConsultasSeleccion();
            ds.guardar(copaMundial.obtener(), d);
        }
        catch(Exception e){
        
        }
    
    }
    
    public void EliminarD(Seleccion d){
    
        try{
        
            ConsultasSeleccion ds = new ConsultasSeleccion();
            ds.eliminar(copaMundial.obtener(), d);
        }
        catch(Exception e){
        
        }
    
    }
    
    public void Buscard(Seleccion d){
    
        try{
        
            ConsultasSeleccion ds = new ConsultasSeleccion();
            ds.buscar(copaMundial.obtener(), d);
        }
        catch(Exception e){
        
        }
    }
    
    public void ActualizarD(Seleccion d){
    
        try{
        
            ConsultasSeleccion ds = new ConsultasSeleccion();
            ds.actualizar(copaMundial.obtener(), d);
        }
        catch(Exception e){
        
        }
    
    }
    
    public Integer MayorD(Seleccion d){
        ConsultasSeleccion ds = new ConsultasSeleccion();
        try{
        
         
            ds.mayorGoles(copaMundial.obtener(), d);
              
        }
        catch(Exception e){

           
        }
        
        return ds.mayor;
        
        
    }
    
    public String MayorS(Seleccion d){
        ConsultasSeleccion ds = new ConsultasSeleccion();
        try{
        
         
            ds.mayorGoles(copaMundial.obtener(), d);
              
        }
        catch(Exception e){

           
        }
        
        return ds.nombre;
        
        
    }
    
     public Integer MayorDifM(Seleccion d){
        ConsultasSeleccion ds = new ConsultasSeleccion();
        try{
        
         
            ds.mayorDif(copaMundial.obtener(), d);
              
        }
        catch(Exception e){

           
        }
        
        return ds.diferencia;
        
        
    }
    
    public String MayorDifN(Seleccion d){
        ConsultasSeleccion ds = new ConsultasSeleccion();
        try{
        
         
            ds.mayorDif(copaMundial.obtener(), d);
              
        }
        catch(Exception e){

           
        }
        
        return ds.nombreS;
        
        
    }
}
    
