
package Controlador;

import Vista.vista;

public class Control {
    
    

    
    public static void main(String[] args) {
        
        vista v=new vista();
        
        v.setVisible(true);
        v.setLocationRelativeTo(null);
        
    }
    
}
    
    
    
    
    
    
    
    
    
